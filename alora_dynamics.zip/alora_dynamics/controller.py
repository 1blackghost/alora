from dynamics import control_servos

BASE=90
SHOULDER1=90
SHOULDER2=90
ELBOW=90
WRIST=90
FINGERS=0
data=[0,0,0,0,0]



def sanitize():
    global BASE, SHOULDER1, SHOULDER2, ELBOW, WRIST, FINGERS
    current_angles = {
        "base": BASE,
        "shoulder1": SHOULDER1,
        "shoulder2": SHOULDER2,
        "elbow": ELBOW,
        "wrist": WRIST,
        "fingers": FINGERS,
    }
    return current_angles

if __name__ == "__main__":
    while True:
        try:
            with open("temp.txt", "r") as f:
                data = eval(f.read())  

                if isinstance(data, list) and len(data) == 5:  
                    b, s1, s2, e, w = data
                    BASE+=int(b)
                    SHOULDER1+=int(s1)
                    ELBOW+=int(e)
                    WRIST+=int(w)
                    if BASE>180 or SHOULDER1>180 or SHOULDER2>180 or ELBOW>180 or WRIST>180:
                        BASE=180
                        SHOULDER1=180
                        SHOULDER2=180-SHOULDER1
                        ELBOW=180
                        WRIST=180
                        FINGERS=180
                    if BASE<0 or SHOULDER1<0 or SHOULDER2<0 or ELBOW<0 or WRIST<0:
                        BASE=0
                        SHOULDER1=0
                        SHOULDER2=180-SHOULDER1
                        ELBOW=0
                        WRIST=0
                        FINGERS=0

                else:
                    print("Invalid data format in temp.txt")
            control_servos(sanitize())

    
        except Exception as e:
            print(f"Error reading or parsing temp.txt: {e}")


